﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WpfApp4
{
    class Validation
    {
        private string name;
        private int age;
        private string creditCard;
        private decimal phoneNumber;
        private decimal amount;

        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
        public string CreditCard { get => creditCard; set => creditCard = value; }
        public decimal PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public decimal Amount { get => amount; set => amount = value; }

        public Validation()
        {

        }

        public Validation(string name,int age,string creditCard,decimal amount)
        {
            this.name = name;
            this.age = age;
            this.creditCard = creditCard;
            this.amount = amount;
        }

        public static bool CheckAge(string strAge)
        {
            int age = 0;
            return int.TryParse(strAge, out age) && age >= 1 && age <= 90;
        }
        public static bool CheckAmount(string strAmount)
        {
            decimal amount = 0;
            return decimal.TryParse(strAmount, out amount) && amount >= 0 && amount <= 10000;
        }

        public static bool CheckPhone(string strPhone)
        {

            Regex r = new Regex(@"^[2-9]\d{2}-\d{3}-\d{4}$");
            if (r.IsMatch(strPhone))
            {
                return true;
            }
            else return false;
        }
        public static bool CheckCreditCard(string card)
        {
            bool flag = false;
            int i;
            if(card!=null && card!=string.Empty&&card.Length==16)
            {
                char[] creditArray = card.ToCharArray();
                flag = true;

                for(i=0;i<creditArray.Length;i++)
                {
                    if(!char.IsDigit((creditArray[i])))
                    {
                        flag = false;
                        break;
                    }
                }
            }
            return flag;
        }
    }
}
