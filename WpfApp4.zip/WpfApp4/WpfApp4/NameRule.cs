﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Controls;
using System.Text.RegularExpressions;

namespace WpfApp4
{
    class NameRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            Regex r = new Regex(@"[~`!@#$%^&*()-+=|\{}':;.,<>/?]");
            if (r.IsMatch((string)value))
            {
                return new ValidationResult(false,
                    string.Format("Special Characters are not allowed"));
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch((string)value, "^[a-zA-Z ]"))
            {
                return new ValidationResult(false,
                  string.Format("Only Alphabets are allowed"));
            }
            else
            {
                return ValidationResult.ValidResult;
            }


           
        }
    }
}
