﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Serialization;
using HairSaloonConsoleApp;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Customer> displayCustomer = null;
        CustomerList myList = new CustomerList();
        public enum CustomerType
        {
            Man,
            Woman,
            Kid
        }

        private string ageNumber;

        public string AgeNumber { get => ageNumber; set => ageNumber = value; }
        public ObservableCollection<Customer> DisplayCustomer { get => displayCustomer; set => displayCustomer = value; }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            File.Delete("customer.xml");

            DisplayCustomer = new ObservableCollection<Customer>();
            string[] names = Enum.GetNames(typeof(CustomerType));
            foreach(string name in names)
            {
                CustomerCombo.Items.Add(name);
            }
            AdditionalCombo.Items.Add("Yes");
            AdditionalCombo.Items.Add("No");
        }
        Customer customer = null;
        private void Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CustomerType myEnum = (CustomerType)CustomerCombo.SelectedIndex;
            switch(myEnum)
            {
                case CustomerType.Man:
                    customer = new Man();
                    AdditionalCombo.Visibility = Visibility.Visible;
                    lblAdditional.Content = "Style Beard";
                    break;
                case CustomerType.Woman:
                    customer = new Woman();
                    AdditionalCombo.Visibility = Visibility.Visible;
                    lblAdditional.Content = "Make up";
                    break;
                case CustomerType.Kid:
                    customer = new Kid();
                    AdditionalCombo.Visibility = Visibility.Visible;
                    lblAdditional.Content = "Sensitive Trimming";
                    break;
            }
        }

       
        public void ResetForm()
        {
            txtCredit.Text = "";
            txtCredit.Foreground = Brushes.Black;
            txtAge.Text = "";
            txtAge.Foreground = Brushes.Black;
            txtName.Text = "";
            txtName.Foreground = Brushes.Black;
            txtPhone.Text = "";
            txtPhone.Foreground = Brushes.Black;
            txtAmount.Text = "";
            txtAmount.Foreground = Brushes.Black;
            CustomerCombo.SelectedIndex = -1;
            AdditionalCombo.SelectedIndex = -1;

        }

        CustomerList xmlCustomerList = null;
        public void WriteXml(CustomerList customerList)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(CustomerList));
            TextWriter txtWriter = new StreamWriter("customer.xml");
            serializer.Serialize(txtWriter, customerList);
            txtWriter.Close();
        }

        private void ReadXml()
        {
            string path = "customer.xml";
            XmlSerializer serializer = new XmlSerializer(typeof(CustomerList));
            StreamReader txtReader = new StreamReader(path);
            xmlCustomerList = (CustomerList)serializer.Deserialize(txtReader);
            txtReader.Close();
        }

        private void BtnShow_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("customer.xml"))
            {
                ReadXml();
                xmlCustomerList.Sort();
                DisplayCustomer.Clear();
                for (int i = 0; i < xmlCustomerList.Count(); i++)
                {
                    Customer cust = xmlCustomerList[i];
                    DisplayCustomer.Add(cust);
                }
                grdCustomer.ItemsSource = DisplayCustomer;
            } else
            {
                MessageBox.Show("No data in customer.xml");
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            bool validate = true;
            if(CustomerCombo.SelectedIndex !=-1)
            {
                int customerType = CustomerCombo.SelectedIndex;
                switch(customerType)
                {
                    case (int)CustomerType.Man:
                        customer = new Man();
                        customer.CustomerType = "Man";
                        string styleBeard = AdditionalCombo.Text;
                        ((Man)customer).IsStyleBeard = (styleBeard.ToUpper() == "Yes") ? true : false;
                        break;
                    case (int)CustomerType.Woman:
                        customer = new Woman();
                        customer.CustomerType = "Woman";
                        string isMakeup = AdditionalCombo.Text;
                        ((Woman)customer).IsMakeUp = (isMakeup.ToUpper() == "Yes") ? true : false;
                        break;
                    case (int)CustomerType.Kid:
                        customer = new Kid();
                        customer.CustomerType = "Kid";
                        string isSensitiveTrim = AdditionalCombo.Text;
                        ((Kid)customer).IsSensitiveTrim = (isSensitiveTrim.ToUpper() == "Yes") ? true : false;
                        break;
                }

                if(!Validation.CheckAge(txtAge.Text))
                {
                    txtAge.Foreground = Brushes.Red;
                    validate = false;
                }
                else
                {
                    txtAge.Foreground = Brushes.Black;
                }
                if (!Validation.CheckAmount(txtAmount.Text))
                {
                    txtAmount.Foreground = Brushes.Red;
                    validate = false;
                }
                else
                {
                    txtAmount.Foreground = Brushes.Black;
                }

                if (!Validation.CheckPhone(txtPhone.Text))
                {
                    txtPhone.Foreground = Brushes.Red;
                    validate = false;
                }
                else
                {
                    txtPhone.Foreground = Brushes.Black;
                }

                if (!Validation.CheckCreditCard(txtCredit.Text))
                {
                    txtCredit.Foreground = Brushes.Red;
                    validate = false;
                }
                else
                {
                    txtCredit.Foreground = Brushes.Black;
                }
                if (validate)
                {
                    int age = int.Parse(txtAge.Text);
                    decimal amount = decimal.Parse(txtAmount.Text);
                    string phoneNumber = txtPhone.Text;
                    string name = txtName.Text;
                    string creditCard = txtCredit.Text;
                    string additional = AdditionalCombo.Text;
                    
                    customer.Card = creditCard;
                    customer.Age = age;
                    customer.PhoneNumber = phoneNumber;
                    customer.Amount = amount;
                    customer.Name = name;
                    myList.Add(customer);
                    ResetForm();

                    if (myList.Count > 0 && validate)
                    {
                        WriteXml(myList);
                        MessageBox.Show("Saved");
                    }
                }
                else
                {
                    MessageBox.Show("Fill all the fields");
                }
            }
            else
            {
                MessageBox.Show("Fill Customer Type");
            }
            
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (txtSearch.Text.Length == 0)
            {
                MessageBox.Show("Search field shouldn't be empty");
            }
            else
            {
                string search = txtSearch.Text;
                int intSearch = int.Parse(search);
                if (search.Length > 0)
                {
                    var query = from myList in xmlCustomerList
                                where myList.Age == intSearch
                                select myList;
                    grdCustomer.ItemsSource = query;
                }
            }

        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            ResetForm();
        }
    }
}
