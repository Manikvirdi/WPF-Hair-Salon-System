﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Controls;

namespace WpfApp4
{
    public class AgeRule :ValidationRule
    {
        int minAge;
        int maxAge;

        public int MinAge { get => minAge; set => minAge = value; }
        public int MaxAge { get => maxAge; set => maxAge = value; }

        public override ValidationResult Validate(object val, CultureInfo culture)
        {
            int numValue = 0;
            if(!int.TryParse(val.ToString(),out numValue))
            {
                return new ValidationResult(false, "The data is wrong");
            }

            if(numValue<minAge ||numValue>maxAge)
            {
                return new ValidationResult(false, "The data is out of range");
            }

            return ValidationResult.ValidResult;
        }
    }
}
