﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Globalization;

namespace WpfApp4
{
    class AmountRule : ValidationRule
    {
        decimal minAmount;
        decimal maxAmount;

        public decimal MinAmount { get => minAmount; set => minAmount = value; }
        public decimal MaxAmount { get => maxAmount; set => maxAmount = value; }

        public override ValidationResult Validate(object val, CultureInfo culture)
        {
            int numValue = 0;
            if (!int.TryParse(val.ToString(), out numValue))
            {
                return new ValidationResult(false, "The data is wrong");
            }

            if (numValue < minAmount || numValue > maxAmount)
            {
                return new ValidationResult(false, "The data is out of range");
            }

            return ValidationResult.ValidResult;
        }
    }
}
