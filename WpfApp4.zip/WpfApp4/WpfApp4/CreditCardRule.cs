﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Globalization;

namespace WpfApp4
{
    class CreditCardRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string card = value.ToString();
            ValidationResult valRes = ValidationResult.ValidResult;
            int i;
            if (card != null && card != string.Empty && card.Length == 16)
            {
                char[] creditArray = card.ToCharArray();
                valRes = ValidationResult.ValidResult;

                for (i = 0; i < creditArray.Length; i++)
                {
                    if (!char.IsDigit((creditArray[i])))
                    {
                        valRes = new ValidationResult(false,
                    string.Format("Phone Number is incorrect"));
                        break;
                    }
                }
            }
            return valRes;
        }
    }
}
