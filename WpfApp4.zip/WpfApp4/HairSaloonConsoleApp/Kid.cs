﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSaloonConsoleApp
{
     public class Kid:Customer
    {
        bool isSensitiveTrim;

        public bool IsSensitiveTrim { get => isSensitiveTrim; set => isSensitiveTrim = value; }

        public override string AdditionalFunction()
        {
            return "Sensitive trimming done";
        }
    }
}
