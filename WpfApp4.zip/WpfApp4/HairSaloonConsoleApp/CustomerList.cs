﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HairSaloonConsoleApp
{


    [XmlRoot("CustomerList")]
    public class CustomerList : IEnumerable<Customer>, IDisposable
    {
        [XmlArray("Customers")]
        [XmlArrayItem("Customers", typeof(Customer))]

        public List<Customer> MyCustomerList
        {
            get => customerList;
            set => customerList = value;
        }

        private List<Customer> customerList = null;

        public CustomerList()
        {
            customerList = new List<Customer>();
        }

        public void Add(Customer c)
        {
            customerList.Add(c);
        }

        public IEnumerator<Customer> GetEnumerator()
        {
            return ((IEnumerable<Customer>)customerList).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<Customer>)customerList).GetEnumerator();
        }

        public int Count
        {
            get
            {
                return customerList.Count;
            }
        }

        public Customer this[int i]
        {
            get { return customerList[i]; }
            set { customerList[i] = value; }
        }

        public void Sort()
        {
            customerList.Sort();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
} 

