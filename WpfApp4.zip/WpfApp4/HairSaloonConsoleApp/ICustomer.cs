﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSaloonConsoleApp
{
    public interface ICustomer : IComparable<ICustomer>
    {


        string Credit { get; }
        string Card { get; set; }
        string PhoneNumber { get; set; }
        decimal Amount { get; set; }
        string Name { get; set; }
        int Age { get; set; }

    }
}
