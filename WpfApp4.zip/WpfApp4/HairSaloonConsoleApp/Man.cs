﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSaloonConsoleApp
{
  public  class Man:Customer

    {
        private bool isStyleBeard;

        public bool IsStyleBeard { get => isStyleBeard; set => isStyleBeard = value; }

        public override string AdditionalFunction()
        {
            return "Beard styling done";
        }
    }
}
