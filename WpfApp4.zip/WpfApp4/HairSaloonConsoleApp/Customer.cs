﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HairSaloonConsoleApp
{
    public delegate string HairSaloonStudio();
    [XmlInclude(typeof(Man)), XmlInclude(typeof(Woman)), XmlInclude(typeof(Kid))]
    public abstract class Customer : ICustomer
    {
        private int age;
        private string card;
        private string customerType;
        private string name;
        private decimal amount;
        private string phoneNumber;
        private HairSaloonStudio myDelegate;
        public string Credit { get => ViewCredit(); }
        public string ViewAmount { get => ViewAmountCreate(); }

        private string ViewAmountCreate()
        {
            string amountString = amount.ToString("c");
            return amountString;
        }

        public string Card { get => card; set => card = value; }
        public int Age { get => age; set => age = value; }
        public string CustomerType { get => customerType; set => customerType = value; }
        public string Name { get => name; set => name = value; }
        public decimal Amount { get => amount; set => amount = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }

        public string ViewDelegate { get => MyDelegate(); }

        [XmlIgnore()]
        public HairSaloonStudio MyDelegate { get => myDelegate; set => myDelegate = value; }

        public Customer()
        {
        myDelegate = AdditionalFunction;
           
            }
        public void WashHair()
        {
            Console.WriteLine("\nHair washed");
        }

        public void CutHair()
        {
            Console.WriteLine("Hair cut");
        }

        public abstract string AdditionalFunction();


        public string ViewCredit()
        {

            int i;
            char[] creditArray = Card.ToCharArray();
            for (i = 4; i < 12; i++)
            {

                creditArray[i] = 'X';

            }

            return new string(creditArray);
        }



        public int CompareTo(ICustomer other)
        {
            return age.CompareTo(other.Age);
        }
    }
}
